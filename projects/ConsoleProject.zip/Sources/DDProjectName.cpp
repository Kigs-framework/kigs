#include <DDProjectName.h>

IMPLEMENT_CLASS_INFO(DDProjectName);

IMPLEMENT_CONSTRUCTOR(DDProjectName)
{

}

void	DDProjectName::ProtectedInit()
{
	// Base modules have been created at this point
	// lets say that the update will sleep 1ms
	SetUpdateSleepTime(1);
}

void	DDProjectName::ProtectedUpdate()
{
}

void	DDProjectName::ProtectedClose()
{
}
