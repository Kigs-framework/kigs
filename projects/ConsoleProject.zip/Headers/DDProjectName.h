#pragma once

#include <CoreBaseApplication.h>

class DDProjectName : public CoreBaseApplication
{
public:
	DECLARE_CLASS_INFO(DDProjectName, CoreBaseApplication, Core);
	DECLARE_CONSTRUCTOR(DDProjectName);

protected:
	void	ProtectedInit() override;
	void	ProtectedUpdate() override;
	void	ProtectedClose() override;
};
