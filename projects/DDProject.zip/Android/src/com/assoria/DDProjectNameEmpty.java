import com.assoria.kigsmain.kigsmainActivity;


// empty
public class DDProjectNameEmpty {
	
	
}
