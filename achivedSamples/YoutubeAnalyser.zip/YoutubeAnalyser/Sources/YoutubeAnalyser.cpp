#include <YoutubeAnalyser.h>
#include <FilePathManager.h>
#include <NotificationCenter.h>
#include "HTTPRequestModule.h"
#include "HTTPConnect.h"
#include "JSonFileParser.h"
#include "ResourceDownloader.h"
#include "TinyImage.h"
#include "JPEGClass.h"
#include "PNGClass.h"
#include "UI/UITexture.h"
#include "TextureFileManager.h"


IMPLEMENT_CLASS_INFO(YoutubeAnalyser);

IMPLEMENT_CONSTRUCTOR(YoutubeAnalyser)
{

}

void	YoutubeAnalyser::ProtectedInit()
{
	// Base modules have been created at this point

	// lets say that the update will sleep 1ms
	SetUpdateSleepTime(1);

	SP<FilePathManager>& pathManager = KigsCore::Singleton<FilePathManager>();
	pathManager->AddToPath(".", "json");

	// Init App
	JSonFileParser L_JsonParser;
	CoreItemSP initP=L_JsonParser.Get_JsonDictionary("launchParams.json");

	mKey = "&key=" + (std::string)initP["GoogleKey"];
	mChannelName = initP["ChannelID"];

	if(!initP["ValidUserCount"].isNil())
		mValidUserCount = initP["ValidUserCount"];

	if (!initP["MaxChannelCount"].isNil())
		mMaxChannelCount = initP["MaxChannelCount"];

	if (!initP["ValidChannelPercent"].isNil())
		mValidChannelPercent = initP["ValidChannelPercent"];
	

	CoreCreateModule(HTTPRequestModule, 0);

	mGoogleConnect = KigsCore::GetInstanceOf("googleConnect", "HTTPConnect");
	mGoogleConnect->setValue("HostName", "www.googleapis.com");
	mGoogleConnect->setValue("Type", "HTTPS");
	mGoogleConnect->setValue("Port", "443");
	mGoogleConnect->Init();

	// requete pour les d�tails d'une chaine par nom d'utilisateur

	std::string currentChannelProgress = "Cache/" + mChannelName + "/";
	currentChannelProgress += mChannelName + ".json";
	CoreItemSP currentP=LoadJSon(currentChannelProgress);

	if (currentP.isNil()) // new channel
	{
		std::string url = "/youtube/v3/channels?part=snippet&id=";
		std::string request = url + mChannelName + mKey;

		mAnswer = mGoogleConnect->retreiveGetAsyncRequest(request.c_str(), "getChannelID", this);
		mAnswer->Init();
	}
	else
	{
		mChannelID=currentP["channelID"];
		LoadChannelStruct(mChannelID, mChannelInfos);
		mState = 1;
	}

	// Load AppInit, GlobalConfig then launch first sequence
	DataDrivenBaseApplication::ProtectedInit();
	mLastUpdate = GetApplicationTimer()->GetTime();

}

void		YoutubeAnalyser::GetChannelInfos(const std::string& id)
{
	
	if (mGetChannelInfos.find(id) != mGetChannelInfos.end()) // already done
	{
		return;
	}

	mGetChannelInfos.insert(id);

	ChannelStruct& toLoad = mFoundChannels[id];
	if (!LoadChannelStruct(id, toLoad))
	{
		std::string url = "/youtube/v3/channels?part=snippet&id=";
		std::string request = url + id + mKey;

		mAnswer = mGoogleConnect->retreiveGetAsyncRequest(request.c_str(), "getChannelID", this);
		mAnswer->Init();
	}
	else
	{
		if (!toLoad.mThumb.mTexture)
		{
			if (toLoad.mThumb.mURL != "")
			{
				CMSP CurrentDownloader = KigsCore::GetInstanceOf("downloader", "ResourceDownloader");
				CurrentDownloader->setValue("URL", toLoad.mThumb.mURL);
				KigsCore::Connect(CurrentDownloader.get(), "onDownloadDone", this, "thumbnailReceived");

				mDownloaderList.push_back({ CurrentDownloader , id });

				CurrentDownloader->Init();
			}
			else
			{
				std::string url = "/youtube/v3/channels?part=snippet&id=";
				std::string request = url + id + mKey;

				mAnswer = mGoogleConnect->retreiveGetAsyncRequest(request.c_str(), "getChannelID", this);
				mAnswer->Init();
			}
		}
	}
}

void	YoutubeAnalyser::ProtectedUpdate()
{
	DataDrivenBaseApplication::ProtectedUpdate();
	
	if (mState == 50)
	{
		return;
	}

	bool needMoreData = false;
	if (myValidUsers >= mValidUserCount)
	{
		if(mState != 50) // finished ?
			mState = 0; // stop updating
	}

	// check state
	switch(mState)
	{
	case 0: // wait
		break;
	case 11:
		needMoreData = true;
	case 1: // channelID ok
	{
		mState = 0; // wait
		// search video list in cache
		JSonFileParser L_JsonParser;
		std::string filename = "Cache/" + mChannelName + "/videos/";
		filename += mChannelID + ".json";
		CoreItemSP initP = L_JsonParser.Get_JsonDictionary(filename);

		std::string nextPageToken;
		if (needMoreData && (!initP.isNil()))
		{
			if (!initP["nextPageToken"].isNil())
			{
				nextPageToken = "&pageToken=" + (std::string)initP["nextPageToken"];
			}
		}

		if (initP.isNil() || (nextPageToken!=""))
		{
			// get latest video list
			// GET https://www.googleapis.com/youtube/v3/search?part=snippet&channelId={CHANNEL_ID}&maxResults=10&order=date&type=video&key={YOUR_API_KEY}
			std::string url = "/youtube/v3/search?part=snippet&channelId=";
			std::string request = url + mChannelID + mKey + nextPageToken + "&maxResults=1&order=date&type=video";
			mAnswer = mGoogleConnect->retreiveGetAsyncRequest(request.c_str(), "getVideoList", this);
			mAnswer->Init();
		}
		else
		{
			CoreItemSP videoList = initP["videos"];
			if (!videoList.isNil())
			{
				for (int i = 0; i < videoList->size(); i++)
				{
					mVideoListToProcess.push_back({ videoList[i],0 }); // 0 means loaded from file
				}
				mState = 2;
			}
			else
			{
				mState = 6;
			}
		}
	}
	break;
	case 21:
		needMoreData = true;
	case 2: // treat video list
	{
		mState = 0; // wait

		if (mVideoListToProcess.size()> mCurrentProcessedVideo)
		{
			mAuthorListToProcess.clear();
			// https://www.googleapis.com/youtube/v3/commentThreads?part=snippet%2Creplies&videoId=_VB39Jo8mAQ&key=[YOUR_API_KEY]' 
			std::string videoID = mVideoListToProcess[mCurrentProcessedVideo].first;
			JSonFileParser L_JsonParser;
			std::string filename = "Cache/" + mChannelName + "/authors/";
			filename += videoID + "_videos.json";
			CoreItemSP initP = L_JsonParser.Get_JsonDictionary(filename);

			std::string nextPageToken;
			if (needMoreData && (!initP.isNil()))
			{
				if (mVideoListToProcess[mCurrentProcessedVideo].second == 1) // downloaded
				{
					if (!initP["nextPageToken"].isNil())
					{
						nextPageToken = "&pageToken=" + (std::string)initP["nextPageToken"];
					}
				}
			}			

			if (initP.isNil() || nextPageToken!="")
			{
				std::string url = "/youtube/v3/commentThreads?part=snippet%2Creplies&videoId=";
				std::string request = url + videoID + mKey + nextPageToken +  "&maxResults=50&order=time";
				mAnswer = mGoogleConnect->retreiveGetAsyncRequest(request.c_str(), "getCommentList", this);
				mAnswer->AddDynamicAttribute(CoreModifiable::ATTRIBUTE_TYPE::STRING, "videoID", videoID.c_str());
				mAnswer->Init();
			}
			else
			{
				CoreItemSP authorList = initP["authors"];
				if (!authorList.isNil())
				{
					mVideoListToProcess[mCurrentProcessedVideo].second = 1; // says it's ok to continue download
					if(mCurrentProcessedVideo < (mVideoListToProcess.size() - 1))
						mCurrentProcessedVideo++;
					
					for (int i = 0; i < authorList->size(); i++)
					{
						mAuthorListToProcess.insert(authorList[i]);
					}
					mState = 3;
				}
				else
				{
					mState = 11;
				}

			}
		}
		else
		{
			mState = 11; // Done
		}
	}
	break;
	case 3: // treat author list
	{
		mState = 0; // wait
		if (mAuthorListToProcess.size())
		{
			
			// https://www.googleapis.com/youtube/v3/subscriptions?part=snippet%2CcontentDetails&channelId=UC_x5XG1OV2P6uZZ5FSM9Ttw&key=[YOUR_API_KEY]'
 
			mCurrentProcessedUser = *mAuthorListToProcess.begin();
			mAuthorListToProcess.erase(mCurrentProcessedUser);

			JSonFileParser L_JsonParser;
			std::string filename = "Cache/" + mChannelName + "/authors/";
			filename += mCurrentProcessedUser + ".json";
			CoreItemSP initP = L_JsonParser.Get_JsonDictionary(filename);

			if (initP.isNil())
			{
				std::string url = "/youtube/v3/subscriptions?part=snippet%2CcontentDetails&channelId=";
				std::string request = url + mCurrentProcessedUser + mKey + "&maxResults=50";
				mAnswer = mGoogleConnect->retreiveGetAsyncRequest(request.c_str(), "getUserSubscribtion", this);
				mAnswer->AddDynamicAttribute(CoreModifiable::ATTRIBUTE_TYPE::STRING, "request", request.c_str());
				mAnswer->Init();
			}
			else
			{
				CoreItemSP channels = initP["channels"];
				mCurrentUser.mHasSubscribed = false;
				mCurrentUser.mPublicChannels.clear();
				if (!channels.isNil())
				{
					for (int i = 0; i < channels->size(); i++)
					{
						std::string chanID=channels[i];

						if (chanID == mChannelID) // ok this user subscribes to analysed channel
						{
							mCurrentUser.mHasSubscribed = true;
						}
						else // don't had myChannelID
						{
							mCurrentUser.mPublicChannels.push_back(chanID);
						}
					}
				}
				
				if(!mCurrentUser.mHasSubscribed)
				{

					// user without subscription
					UserStruct currentUser;
					currentUser.mHasSubscribed = false;
					currentUser.mPublicChannels.clear();
					mFoundUsers[mCurrentProcessedUser] = currentUser;
				}
				else
				{
					myValidUsers++;
					for (const auto& c : mCurrentUser.mPublicChannels)
					{
						// add new found channel
						auto found = mFoundChannels.find(c);
						if (found == mFoundChannels.end())
						{
							ChannelStruct	toAdd;
							toAdd.mThumb.mFormat = -1;
							toAdd.mSubscribersCount = 1;
							LoadChannelStruct(c, toAdd);
							mFoundChannels[c] = toAdd;

						}
						else
						{
							(*found).second.mSubscribersCount++;
						}
					}

					mFoundUsers[mCurrentProcessedUser] = mCurrentUser;
					
				}
				mState = 3; // process next author
			}
		}
		else // go back to video process 
		{
			mState = 21;
		}
	}
	break;
	case 10:// error
	{
		if (mErrorCode == 403)
		{
			SimpleCall("RequestStateChange", "ErrorSequence.xml");
			mState = 0;
		}
		else
		{
			// wait no more Async task
			if (!KigsCore::Instance()->hasAsyncRequestPending())
			{
				mShowedChannels.clear();
				myNeedExit = true;
			}
		}
	}
	break;
	default:
		printf("unknown state");
	}


	// update graphics
	double dt = GetApplicationTimer()->GetTime() - mLastUpdate;
	if (dt > 1.0)
	{
		mLastUpdate = GetApplicationTimer()->GetTime();
		if (mCountUserText)
		{
			char userCount[256];
			sprintf(userCount,"Treated users : %d", mFoundUsers.size());
			mCountUserText->setValue("Text", userCount);
		}
		if (mValidUserText)
		{
			char userCount[256];
			sprintf(userCount, "Valid users : %d", myValidUsers);
			mValidUserText->setValue("Text", userCount);
		}
		if (mFoundChannelsText)
		{
			char userCount[256];
			sprintf(userCount, "Found Channels : %d", mFoundChannels.size());
			mFoundChannelsText->setValue("Text", userCount);
		}

		// check if Channel texture was loaded

		if (mChannelInfos.mThumb.mTexture && mMainThumnail)
		{
			const SP<UITexture>& tmp = mMainThumnail;

			if (!tmp->GetTexture())
			{
				tmp->addItem(mChannelInfos.mThumb.mTexture);

				std::vector<CMSP> sons;
				tmp->GetSonInstancesByName("UIText", "ChannelName", sons);
				if (sons.size())
				{
					(*(sons.begin()))->setValue("Text", mChannelInfos.mName);
				}
			}
		}

		refreshAllThumbs();
	}
	
}

void	YoutubeAnalyser::refreshAllThumbs()
{
	if (myValidUsers < 10)
	{
		return;
	}

	bool somethingChanged = false;

	float wantedpercent = mValidChannelPercent;

	if (myValidUsers < mValidUserCount)
	{
		wantedpercent = (mValidChannelPercent * mValidUserCount)/(float)myValidUsers;
	}
	
	// get all parsed channels and get the ones with more than mValidChannelPercent subscribed users
	std::vector<std::pair<ChannelStruct,std::string>>	toShow;
	for (auto c : mFoundChannels)
	{
		if (c.second.mSubscribersCount > 1)
		{
			float percent = (float)c.second.mSubscribersCount / (float)myValidUsers;
			if (percent > wantedpercent)
			{
				toShow.push_back({ c.second,c.first });
			}
		}
	}

	if (toShow.size() == 0)
	{
		return;
	}

	std::sort(toShow.begin(), toShow.end(), [](const std::pair<ChannelStruct, std::string>& a1, const std::pair<ChannelStruct, std::string>& a2)
		{
			return (a1.first.mSubscribersCount> a2.first.mSubscribersCount);
		}
	);

	// check for channels already shown / to remove

	std::unordered_map<std::string, unsigned int>	currentShowedChannels;
	int toShowCount = 0;
	for (const auto& tos : toShow)
	{
		currentShowedChannels[tos.second] = 1;
		toShowCount++;
		if (toShowCount >= mMaxChannelCount)
			break;
	}


	for (const auto& s : mShowedChannels)
	{
		if (currentShowedChannels.find(s.first) == currentShowedChannels.end())
		{
			currentShowedChannels[s.first] = 0;
		}
		else
		{
			currentShowedChannels[s.first]++;
		}
	}

	// add / remove items
	for (const auto& update : currentShowedChannels)
	{
		if (update.second == 0) // to remove 
		{
			auto toremove = mShowedChannels.find(update.first);
			mMainInterface->removeItem((*toremove).second);
			mShowedChannels.erase(toremove);
			somethingChanged = true;
		}
		else if (update.second == 1) // to add
		{
			std::string thumbName = "thumbNail_"+ update.first;
			CMSP toAdd = CoreModifiable::Import("Thumbnail.xml", false, false, nullptr, thumbName);
			mShowedChannels[update.first] = toAdd;
			mMainInterface->addItem(toAdd);
			somethingChanged = true;
		}
	}

	float dangle = 2.0f * KFLOAT_CONST_PI / 7.0f;
	float angle = 0.0f;
	float ray = 0.15f;
	float dray = 0.01f;
	toShowCount = 0;
	for (const auto& toPlace : toShow)
	{
		auto found=mShowedChannels.find(toPlace.second);
		if (found != mShowedChannels.end())
		{
			const CMSP& toSetup = (*found).second;
			toSetup("Dock") = v2f(0.5f + ray *cosf(angle), 0.5f + ray * sinf(angle));
			angle += dangle;
			dangle = 2.0f * KFLOAT_CONST_PI / (2.0f+50.0f*ray);
			ray += dray;
			dray *= 0.98f;
			toSetup["ChannelName"]("Text") = toPlace.first.mName;

			char Asciipercent[128];

			int percent = (int)(100.0f*((float)toPlace.first.mSubscribersCount / (float)myValidUsers));
			sprintf(Asciipercent, "%d", percent);

			toSetup["ChannelPercent"]("Text")=Asciipercent;

			const SP<UITexture>& checkTexture = toSetup;

			if (!checkTexture->GetTexture())
			{
				somethingChanged = true;
				if (toPlace.first.mThumb.mTexture)
				{
					checkTexture->addItem(toPlace.first.mThumb.mTexture);
				}
				else
				{
					GetChannelInfos(toPlace.second);
				}

			}
		}
		toShowCount++;
		if (toShowCount >= mMaxChannelCount)
			break;
	}

	if (myValidUsers >= mValidUserCount)
	{
		if (somethingChanged == false)
		{
			mState = 50; // finished
			SaveStatFile();
		}
	}
}

void		YoutubeAnalyser::SaveStatFile()
{

	std::string filename = mChannelInfos.mName.ToString();
	filename += "_stats.csv";


	// get all parsed channels and get the ones with more than mValidChannelPercent subscribed users
	std::vector<std::pair<ChannelStruct, std::string>>	toSave;
	for (auto c : mFoundChannels)
	{
		if (c.second.mSubscribersCount > 1)
		{
			float percent = (float)c.second.mSubscribersCount / (float)myValidUsers;
			if (percent > mValidChannelPercent)
			{
				toSave.push_back({ c.second,c.first });
			}
		}
	}

	std::sort(toSave.begin(), toSave.end(), [](const std::pair<ChannelStruct, std::string>& a1, const std::pair<ChannelStruct, std::string>& a2)
		{
			return (a1.first.mSubscribersCount > a2.first.mSubscribersCount);
		}
	);

	SmartPointer<::FileHandle> L_File = Platform_fopen(filename.c_str(), "wb");
	if (L_File->myFile)
	{

		std::string header = "Channel Name,Channel ID,Percent\n";
		Platform_fwrite(header.c_str(), 1, header.length(), L_File.get());
		char saveBuffer[4096];
		for (const auto& p : toSave)
		{
			int percent = (int)(100.0f * ((float)p.first.mSubscribersCount / (float)myValidUsers));
			sprintf(saveBuffer, "\"%s\",%s,%d\n",p.first.mName.ToString().c_str(),p.second.c_str(), percent);
			Platform_fwrite(saveBuffer, 1, strlen(saveBuffer), L_File.get());
		}
		
		Platform_fclose(L_File.get());
	}
}

void	YoutubeAnalyser::ProtectedClose()
{
	DataDrivenBaseApplication::ProtectedClose();
	CoreDestroyModule(HTTPRequestModule);
}

void	YoutubeAnalyser::ProtectedInitSequence(const kstl::string& sequence)
{
	if (sequence == "sequencemain")
	{
		mMainInterface = GetFirstInstanceByName("UIItem", "Interface");

		mCountUserText = mMainInterface["TreatedUsers"];
		mValidUserText = mMainInterface["ValidUsers"];
		mFoundChannelsText = mMainInterface["FoundChannels"];
		mMainThumnail = mMainInterface["thumbnail"];
		
	}
}
void	YoutubeAnalyser::ProtectedCloseSequence(const kstl::string& sequence)
{
	if (sequence == "sequencemain")
	{
		mCountUserText = nullptr;
		mValidUserText = nullptr;
		mFoundChannelsText = nullptr;
		mMainThumnail = nullptr;
		mMainInterface = nullptr;

		mFoundChannels.clear();
		mShowedChannels.clear();
		mChannelInfos.mThumb.mTexture = nullptr;
		mDownloaderList.clear();
	}
}

CoreItemSP	YoutubeAnalyser::RetrieveJSON(CoreModifiable* sender)
{
	void* result = nullptr;
	sender->getValue("ReceivedBuffer", result);

	if (result)
	{
		CoreRawBuffer* r = (CoreRawBuffer*)result;
		std::string_view received(r->data(), r->size());

		std::string validstring(received);

		usString	utf8string((UTF8Char*)validstring.c_str());

		JSonFileParserUTF16 L_JsonParser;
		CoreItemSP result= L_JsonParser.Get_JsonDictionaryFromString(utf8string);

		if (!result["error"].isNil())
		{
			mState = 10;
			mErrorCode = result["error"]["code"];
		}
		else
		{
			return result;
		}
	}

	return nullptr;
}

CoreItemSP	YoutubeAnalyser::LoadJSon(const std::string& fname)
{
	JSonFileParser L_JsonParser;
	CoreItemSP initP = L_JsonParser.Get_JsonDictionary(fname);
	return initP;
}


void	YoutubeAnalyser::thumbnailReceived(CoreRawBuffer* data, CoreModifiable* downloader)
{
	TinyImage* img = nullptr;

	unsigned int imgformat = 0;
	if (data)
	{
		unsigned char* tmp =(unsigned char*) data->buffer();

		if ((tmp[0] == 0xFF) && (tmp[1] == 0xD8) && (tmp[2] == 0xFF))
		{
			// jpg
			img = new JPEGClass(data);
			imgformat = 0;
		}
		else if ((tmp[0] == 0x89) && (tmp[1] == 0x50) && (tmp[2] == 0x4E))
		{
			// png
			img = new PNGClass(data);
			imgformat = 1;
		}
	}
	
	// search used downloader in vector

	std::vector<std::pair<CMSP, std::string> > tmpList;

	for (const auto& p : mDownloaderList)
	{
		if (p.first.get() == downloader)
		{
			if (img)
			{
				ChannelStruct* toFill = nullptr;
				if (p.second == mChannelID)
				{
					toFill = &mChannelInfos;
				}
				else 
				{
					auto f = mFoundChannels.find(p.second);
					if (f != mFoundChannels.end())
					{
						toFill = &(*f).second;
					}
				}
				toFill->mThumb.mFormat = imgformat;

				std::string filename= "Cache/Thumbs/";
				filename += p.second;
				if (toFill->mThumb.mFormat == 0)
				{
					filename += ".jpg";
				}
				else
				{
					filename += ".png";
				}

				// export image
				SmartPointer<::FileHandle> L_File = Platform_fopen(filename.c_str(), "wb");
				if (L_File->myFile)
				{
					Platform_fwrite(data->buffer(),1, data->length(), L_File.get());
					Platform_fclose(L_File.get());
				}

				toFill->mThumb.mTexture = KigsCore::GetInstanceOf((std::string)toFill->mName + "tex", "Texture");
				toFill->mThumb.mTexture->Init();

				SmartPointer<TinyImage>	imgsp = OwningRawPtrToSmartPtr(img);
				toFill->mThumb.mTexture->CreateFromImage(imgsp);

				SaveChannelStruct(p.second, *toFill);
			}
		}
		else
		{
			tmpList.push_back(p);
		}
	}
	mDownloaderList = std::move(tmpList);
}

DEFINE_METHOD(YoutubeAnalyser, getChannelID)
{
	auto json=RetrieveJSON(sender);

	if (!json.isNil())
	{
		CoreItemSP IDItem = json["items"][0]["id"];

		if (!IDItem.isNil())
		{
			ChannelStruct* currentChan = nullptr;
			bool isMainChannel=false;
			if (mChannelID == "") // main channel
			{
				isMainChannel = true;
				mChannelID = IDItem;
				currentChan = &mChannelInfos;

				// save channel id
				{
					JSonFileParser L_JsonParser;
					CoreItemSP initP = CoreItemSP::getCoreMap();
					initP->set("channelID", CoreItemSP::getCoreValue(mChannelID));

					std::string filename = "Cache/" + mChannelName + "/";
					filename += mChannelName + ".json";
					L_JsonParser.Export((CoreMap<std::string>*)initP.get(), filename);
				}
			}
			else
			{
				auto f = mFoundChannels.find((std::string)IDItem);
				if (f != mFoundChannels.end())
				{
					currentChan = &(*f).second;
				}
			}

			if (currentChan)
			{
				CoreItemSP infos = json["items"][0]["snippet"];
				currentChan->mName = infos["title"];
				std::string imgurl = infos["thumbnails"]["default"]["url"];
				CMSP CurrentDownloader = KigsCore::GetInstanceOf("downloader", "ResourceDownloader");
				CurrentDownloader->setValue("URL", imgurl);
				KigsCore::Connect(CurrentDownloader.get(), "onDownloadDone", this, "thumbnailReceived");

				mDownloaderList.push_back({ CurrentDownloader , IDItem });

				CurrentDownloader->Init();

				if(isMainChannel)
					mState = 1;

				return true;
			}

		}
	}
	mState = 10; // Error
	return true;
}

void		YoutubeAnalyser::SaveAuthorList(const std::string& nextPage,const std::string& videoID )
{
	JSonFileParser L_JsonParser;

	std::string filename = "Cache/" + mChannelName + "/authors/";

	filename += videoID + "_videos.json";

	CoreItemSP initP;
	initP = L_JsonParser.Get_JsonDictionary(filename);

	if (initP.isNil())
	{
		initP = CoreItemSP::getCoreMap();
	}

	if (nextPage != "")
	{
		initP->set("nextPageToken", CoreItemSP::getCoreValue(nextPage));
	}
	else
	{
		initP->erase("nextPageToken");
	}

	CoreItemSP v = initP["authors"];
	if (v.isNil())
	{
		v = CoreItemSP::getCoreVector();
	}

	for (const auto& auth : mAuthorListToProcess)
	{
		v->set("", CoreItemSP::getCoreValue(auth));
	}

	initP->set("authors", v);

	L_JsonParser.Export((CoreMap<std::string>*)initP.get(), filename);
}

void YoutubeAnalyser::SaveVideoList(const std::string& nextPage)
{
	JSonFileParser L_JsonParser;

	std::string filename = "Cache/" + mChannelName + "/videos/";
	filename += mChannelID + ".json";

	CoreItemSP initP = L_JsonParser.Get_JsonDictionary(filename);

	if (initP.isNil())
	{
		initP = CoreItemSP::getCoreMap();
	}

	if (nextPage != "")
	{
		initP->set("nextPageToken", CoreItemSP::getCoreValue(nextPage));
	}
	else
	{
		initP->erase("nextPageToken");
	}

	CoreItemSP v = initP["videos"];
	if (v.isNil())
	{
		v = CoreItemSP::getCoreVector();
	}

	for (const auto& vid : mVideoListToProcess)
	{
		v->set("", CoreItemSP::getCoreValue(vid.first));
	}

	initP->set("videos", v);

	L_JsonParser.Export((CoreMap<std::string>*)initP.get(), filename);

}

void		YoutubeAnalyser::SaveAuthor(const std::string& id)
{
	JSonFileParser L_JsonParser;
	CoreItemSP initP = CoreItemSP::getCoreMap();

	auto it = mFoundUsers.find(id);
	if (it != mFoundUsers.end())
	{
		UserStruct& currentUser = (*it).second;

		if (currentUser.mHasSubscribed)
		{
			CoreItemSP channelList = CoreItemSP::getCoreVector();

			channelList->set("", CoreItemSP::getCoreValue(mChannelID));

			for (const auto& c : currentUser.mPublicChannels)
			{
				channelList->set("", CoreItemSP::getCoreValue(c));
			}
		
			initP->set("channels", channelList);
		}

		std::string filename = "Cache/" + mChannelName + "/authors/";
		filename += id + ".json";

		L_JsonParser.Export((CoreMap<std::string>*)initP.get(), filename);
	}

}

void		YoutubeAnalyser::SaveChannelStruct(const std::string& id, const ChannelStruct& ch)
{
	JSonFileParserUTF16 L_JsonParser;
	CoreItemSP initP = CoreItemSP::getCoreItemOfType<CoreMap<usString>>();
	initP->set("Name",CoreItemSP::getCoreValue(ch.mName));
	if (ch.mThumb.mFormat != -1)
	{
		initP->set("ImgFormat", CoreItemSP::getCoreValue((int)ch.mThumb.mFormat));
	}
	else if(ch.mThumb.mURL != "")
	{
		initP->set("ImgURL", CoreItemSP::getCoreValue((usString)ch.mThumb.mURL));
	}
	std::string filename = "Cache/Channels/";
	filename += id + ".json";

	L_JsonParser.Export((CoreMap<usString>*)initP.get(),filename);
}
bool		YoutubeAnalyser::LoadChannelStruct(const std::string& id, ChannelStruct& ch)
{
	JSonFileParserUTF16 L_JsonParser;
	std::string filename = "Cache/Channels/";
	filename += id + ".json";
	CoreItemSP initP = L_JsonParser.Get_JsonDictionary(filename);
	if (initP.isNil()) // request
	{
		return false;
	}
	
	ch.mName = initP["Name"];
	ch.mSubscribersCount = 0;
	if (!initP["ImgFormat"].isNil())
	{
		auto& textureManager = KigsCore::Singleton<TextureFileManager>();
		ch.mThumb.mFormat = initP["ImgFormat"];
		filename = "Cache/Thumbs/";
		filename += id;
		if (ch.mThumb.mFormat == 0)
		{
			filename += ".jpg";
		}
		else
		{
			filename += ".png";
		}
		ch.mThumb.mTexture = textureManager->GetTexture(filename);
	}
	else if (!initP["ImgURL"].isNil())
	{
		ch.mThumb.mURL = initP["ImgURL"];
	}
	return true;
}


DEFINE_METHOD(YoutubeAnalyser, getVideoList)
{

	auto json = RetrieveJSON(sender);

	std::string nextPageToken;

	if (!json.isNil())
	{
		if (!json["nextPageToken"].isNil())
		{
			nextPageToken = json["nextPageToken"];
		}

		CoreItemSP videoList = json["items"];

		if (!videoList.isNil())
		{
			if (videoList->size())
			{
				for (int i = 0; i < videoList->size(); i++)
				{
					CoreItemSP video = videoList[i];
					if (!video["id"]["kind"].isNil())
					{
						std::string kind = video["id"]["kind"];
						if (kind == "youtube#video")
						{
							if (!video["id"]["videoId"].isNil())
							{
								mVideoListToProcess.push_back({ (std::string)video["id"]["videoId"],1 }); // 1 means just requested
							}
						}
					}
				}
			}

			// save list state
			{
				SaveVideoList(nextPageToken);
			}

			mState = 2; // process video

			return true;
		}
	}

	mState = 10; // error
	
	return true;
}

DEFINE_METHOD(YoutubeAnalyser, getCommentList)
{
	auto json = RetrieveJSON(sender);
	std::string nextPageToken;

	if (!json.isNil())
	{
		if (!json["nextPageToken"].isNil())
		{
			nextPageToken = json["nextPageToken"];
		}
		else
		{
			// comments for this video were all processed
			mCurrentProcessedVideo++;
		}

		CoreItemSP commentThreads = json["items"];

		if (!commentThreads.isNil())
		{
			if (commentThreads->size())
			{
				for (int i = 0; i < commentThreads->size(); i++)
				{
					CoreItemSP topComment = commentThreads[i]["snippet"]["topLevelComment"]["snippet"];
					if (!topComment.isNil())
					{
						std::string authorID = topComment["authorChannelId"]["value"];

						// check if not already processed
						if (mFoundUsers.find(authorID) == mFoundUsers.end())
						{
							mAuthorListToProcess.insert(authorID);
						}
					}
					int answerCount = commentThreads[i]["snippet"]["totalReplyCount"];
					if (answerCount)
					{
						for (int j = 0; j < answerCount; j++)
						{
							CoreItemSP replies = commentThreads[i]["replies"]["comments"][j]["snippet"];
							if (!replies.isNil())
							{
								std::string authorID = replies["authorChannelId"]["value"];

								// check if not already processed
								if (mFoundUsers.find(authorID) == mFoundUsers.end())
								{
									mAuthorListToProcess.insert(authorID);
								}
							}
						}
					}
				}
			}

			// save authors state
			{
				std::string id = sender->getValue<std::string>("videoID");
				SaveAuthorList(nextPageToken,id);
			}

			mState = 3; // process author
			return true;
		}
	}

	mState = 10;
	return true;
}

DEFINE_METHOD(YoutubeAnalyser, getUserSubscribtion)
{
	bool isNewPage=false;
	sender->getValue("NewPage", isNewPage);
	
	if (!isNewPage) // first page
	{
		mCurrentUser.mHasSubscribed = false;
		mCurrentUser.mPublicChannels.clear();
		mTmpUserChannels.clear();
	}

	std::string nextPageToken;

	auto json = RetrieveJSON(sender);

	bool isLastPage = true;

	if (!json.isNil())
	{
		if (!json["nextPageToken"].isNil())
		{
			isLastPage = false;
			nextPageToken = json["nextPageToken"];
		}

		CoreItemSP subscriptions = json["items"];
		if (!subscriptions.isNil())
		{
			if (subscriptions->size())
			{
				for (int i = 0; i < subscriptions->size(); i++)
				{
					CoreItemSP subscription = subscriptions[i]["snippet"]["resourceId"]["channelId"];
					if (!subscription.isNil())
					{

						usString title = subscriptions[i]["snippet"]["title"];
						std::string url = subscriptions[i]["snippet"]["thumbnails"]["default"]["url"];
						std::string chanID = subscription;

						if (chanID == mChannelID) // ok this user subscribes to analysed channel
						{
							mCurrentUser.mHasSubscribed = true;
						}
						else // don't had myChannelID
						{
							mTmpUserChannels.push_back({ chanID,{title,url} });
						}
					}
				}
			}
		}
	}
	if (isLastPage)
	{
		if (mCurrentUser.mHasSubscribed)
		{
			myValidUsers++;
			for (const auto& c : mTmpUserChannels)
			{
				mCurrentUser.mPublicChannels.push_back(c.first);

				// add new found channel
				auto found = mFoundChannels.find(c.first);
				if (found == mFoundChannels.end())
				{
					ChannelStruct	toAdd;
					toAdd.mName = c.second.first;
					toAdd.mThumb.mURL = c.second.second;
					toAdd.mThumb.mFormat = -1;
					toAdd.mSubscribersCount = 1;
					mFoundChannels[c.first] = toAdd;

					SaveChannelStruct(c.first, toAdd);
				}
				else
				{
					(*found).second.mSubscribersCount++;
				}
			}

			mFoundUsers[mCurrentProcessedUser] = mCurrentUser;

		}
		else  // add user without subscription
		{
			UserStruct currentUser;
			currentUser.mHasSubscribed = false;
			currentUser.mPublicChannels.clear();
			mFoundUsers[mCurrentProcessedUser] = currentUser;
		}
		SaveAuthor(mCurrentProcessedUser);
		mState = 3; // process next author
	}
	else
	{
		// call it again
		std::string request;
		sender->getValue("request", request);
		std::string requestPage = request + "&pageToken=" + nextPageToken;
		mAnswer = mGoogleConnect->retreiveGetAsyncRequest(requestPage.c_str(), "getUserSubscribtion", this);
		mAnswer->AddDynamicAttribute(CoreModifiable::ATTRIBUTE_TYPE::STRING, "request", request.c_str());
		mAnswer->AddDynamicAttribute(CoreModifiable::ATTRIBUTE_TYPE::BOOL, "NewPage", true);
		mAnswer->Init();
	}
	
	return true;
}

