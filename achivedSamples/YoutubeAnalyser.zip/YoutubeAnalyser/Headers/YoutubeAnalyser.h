#pragma once

#include <DataDrivenBaseApplication.h>
#include "HTTPConnect.h"
#include "Texture.h"

class ResourceDownloader;

class YoutubeAnalyser : public DataDrivenBaseApplication
{
public:
	DECLARE_CLASS_INFO(YoutubeAnalyser, DataDrivenBaseApplication, Core);
	DECLARE_CONSTRUCTOR(YoutubeAnalyser);

protected:

	std::string						mKey = "";
	unsigned int					mState=0;
	// general application parameters
	unsigned int					mValidUserCount=100;
	unsigned int					mMaxChannelCount=16;
	float							mValidChannelPercent=0.02f;

	struct ThumbnailStruct
	{
		unsigned int				mFormat; // 0 = jpg , 1 =png
		SP<Texture>					mTexture = nullptr;
		std::string					mURL;
	};

	struct ChannelStruct
	{
		// channel name
		usString					mName;
		unsigned int				mSubscribersCount;
		ThumbnailStruct				mThumb;
	};

	friend inline bool operator<(ChannelStruct const& a, ChannelStruct const& b);

	struct UserStruct
	{
		// list of Channel IDs
		std::vector<std::string>	mPublicChannels;
		bool						mHasSubscribed;
	};
	

	void	ProtectedInit() override;
	void	ProtectedUpdate() override;
	void	ProtectedClose() override;

	DECLARE_METHOD(getChannelID);
	DECLARE_METHOD(getVideoList);
	DECLARE_METHOD(getCommentList);
	DECLARE_METHOD(getUserSubscribtion);

	COREMODIFIABLE_METHODS(getChannelID, getVideoList, getCommentList, getUserSubscribtion);

	void	refreshAllThumbs();

	void	thumbnailReceived(CoreRawBuffer* data, CoreModifiable* downloader);

	WRAP_METHODS(thumbnailReceived);

	// utility

	CoreItemSP	RetrieveJSON(CoreModifiable* sender);
	CoreItemSP	LoadJSon(const std::string& fname);

	void		SaveChannelStruct(const std::string& id, const ChannelStruct& ch);
	bool		LoadChannelStruct(const std::string& id, ChannelStruct& ch);
	void		GetChannelInfos(const std::string& id);
	void		SaveVideoList(const std::string& nextPage);
	void		SaveAuthorList(const std::string& nextPage, const std::string& videoID);
	void		SaveAuthor(const std::string& id);

	void		SaveStatFile();

	void	ProtectedInitSequence(const kstl::string& sequence) override;
	void	ProtectedCloseSequence(const kstl::string& sequence) override;

	SP<HTTPConnect>									mGoogleConnect = nullptr;
	SP<HTTPAsyncRequest>							mAnswer = nullptr;
	std::vector<std::pair<CMSP, std::string> >		mDownloaderList;
	std::string										mChannelName;
	std::string										mChannelID;
	ChannelStruct									mChannelInfos;
	unsigned int									mErrorCode=0;

	unsigned int			myValidUsers = 0;


	std::unordered_map<std::string, UserStruct>		mFoundUsers;

	std::unordered_map<std::string, ChannelStruct>	mFoundChannels;
	std::set<std::string>							mGetChannelInfos;

	std::unordered_map<std::string, CMSP>			mShowedChannels;

	std::vector<std::pair<std::string,int>>			mVideoListToProcess;
	unsigned int									mCurrentProcessedVideo=0;
	std::set<std::string>							mAuthorListToProcess;

	std::string											mCurrentProcessedUser;
	UserStruct											mCurrentUser;
	std::vector<std::pair<std::string, std::pair<usString,std::string>> >	mTmpUserChannels;


	CMSP											mCountUserText;
	CMSP											mValidUserText;
	CMSP											mFoundChannelsText;
	CMSP											mMainThumnail;
	CMSP											mMainInterface;
	double											mLastUpdate;
};


inline bool operator<(YoutubeAnalyser::ChannelStruct const& a, YoutubeAnalyser::ChannelStruct const& b) 
{
	return a.mSubscribersCount > b.mSubscribersCount;
}