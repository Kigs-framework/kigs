#pragma once

#include <DataDrivenBaseApplication.h>
#include "ThreadPoolManager.h"

class TestThreads : public DataDrivenBaseApplication
{
public:
	DECLARE_CLASS_INFO(TestThreads, DataDrivenBaseApplication, Core);
	DECLARE_CONSTRUCTOR(TestThreads);

protected:
	void	ProtectedInit() override;
	void	ProtectedUpdate() override;
	void	ProtectedClose() override;

	
	void	DoSomethingInThread();

	void	Task1();
	void	Task2();
	void	Task3();
	void	Task4();
	void	Task5();

	WRAP_METHODS(DoSomethingInThread,Task1, Task2, Task3, Task4, Task5);

	void	ProtectedInitSequence(const kstl::string& sequence) override;
	void	ProtectedCloseSequence(const kstl::string& sequence) override;

	SP<ThreadPoolManager>	mThreadPoolManager;
};
