#include <TestThreads.h>
#include <FilePathManager.h>
#include <NotificationCenter.h>
#include "ModuleThread.h"
#include <stdio.h>
#include <iostream>

IMPLEMENT_CLASS_INFO(TestThreads);

IMPLEMENT_CONSTRUCTOR(TestThreads)
{

}

void	TestThreads::ProtectedInit()
{
	// Base modules have been created at this point

	// lets say that the update will sleep 1ms
	SetUpdateSleepTime(1);

	SP<FilePathManager>& pathManager = KigsCore::Singleton<FilePathManager>();
	pathManager->AddToPath(".", "xml");

	// Load AppInit, GlobalConfig then launch first sequence
	DataDrivenBaseApplication::ProtectedInit();

	CoreCreateModule(ModuleThread, 0);

	CMSP	athread = KigsCore::GetInstanceOf("athread", "Thread");
	athread->setValue("Method", "DoSomethingInThread");
	athread->setValue("Callee", "DataDrivenBaseApplication:TestThreads");
	athread->Init();


	mThreadPoolManager= KigsCore::GetInstanceOf("threadPool", "ThreadPoolManager");
	mThreadPoolManager->Init();
	
#define NBTASK	20
	MethodCallingStruct*	tasks[NBTASK];
	for (int i = 0; i < NBTASK; i++)
	{
		tasks[i] = new MethodCallingStruct;
		tasks[i]->myMethodInstance = this;

		char currentTaskName[50];
		memset(currentTaskName, 0, 50);
		sprintf(currentTaskName, "Task%d", (i % 5) + 1);
		tasks[i]->myMethodID = std::string(currentTaskName);
		tasks[i]->myPrivateParams = nullptr;
	}


	ThreadPoolManager::TaskGroupHandle* tskgrp= mThreadPoolManager->createTaskGroup(tasks, NBTASK);
	mThreadPoolManager->LaunchTaskGroup(tskgrp);
}

void	TestThreads::ProtectedUpdate()
{
	DataDrivenBaseApplication::ProtectedUpdate();

	//std::cout << "time = " << GetApplicationTimer()->GetTime() << std::endl;

	static unsigned int TaskCount = 0;
	unsigned int currentTaskCount = mThreadPoolManager->getRunningTaskCount();
	if (currentTaskCount != TaskCount)
	{
		std::cout << "Current running task count = " << currentTaskCount << std::endl;
		TaskCount = currentTaskCount;
	}

	if (GetApplicationTimer()->GetTime() > 10)
	{
		myNeedExit = true;
	}
}

void	TestThreads::ProtectedClose()
{
	CoreDestroyModule(ModuleThread);
	
	DataDrivenBaseApplication::ProtectedClose();
 }

void	TestThreads::ProtectedInitSequence(const kstl::string& sequence)
{
	if (sequence == "sequencemain")
	{

	}
}
void	TestThreads::ProtectedCloseSequence(const kstl::string& sequence)
{
	if (sequence == "sequencemain")
	{
		
	}
}


void	TestThreads::DoSomethingInThread()
{
	for (int i = 0; i < 20; i++)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(100));
		std::cout << "i = " << i << std::endl;
	}
}


void	TestThreads::Task1()
{
	for (int i = 0; i < 30; i++)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(40));
		std::cout << ">> Task1 i = " << i << std::endl;
	}
}

void	TestThreads::Task2()
{
	for (int i = 0; i < 30; i++)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(40));
		std::cout << ">>>> Task2 i = " << i << std::endl;
	}
}

void	TestThreads::Task3()
{
	for (int i = 0; i < 30; i++)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(30));
		std::cout << ">>>>>> Task3 i = " << i << std::endl;
	}
}

void	TestThreads::Task4()
{
	for (int i = 0; i < 30; i++)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(20));
		std::cout << ">>>>>>>> Task4 i = " << i << std::endl;
	}
}

void	TestThreads::Task5()
{
	for (int i = 0; i < 30; i++)
	{
		std::this_thread::sleep_for(std::chrono::milliseconds(50));
		std::cout << ">>>>>>>>>> Task5 i = " << i << std::endl;
	}
}
